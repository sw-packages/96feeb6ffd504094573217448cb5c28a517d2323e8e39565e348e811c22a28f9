## Contact

- Send me an email: [antonbachin@yahoo.com](mailto:antonbachin@yahoo.com).
- Visit the [GitHub]($repo) project to open an issue or get a development
  version.

I'm happy to hear any feedback. If you have any trouble using the library or
parsing the documentation, please don't hesitate to let me know. I'd also be
interested to hear about your use case, if you are willing to share :)

And, if you find this library helpful, give it a star on GitHub to let me know
you use it :)

%% description =
Contact information for Better Enums bugs, issues, support, and feedback.
