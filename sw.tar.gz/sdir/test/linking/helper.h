#ifndef HELPER_H
#define HELPER_H

#include "shared.h"

void print(Channel channel);

#endif // #ifndef HELPER_H
