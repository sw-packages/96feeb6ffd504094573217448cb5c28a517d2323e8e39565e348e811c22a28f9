#include "shared.h"
#include "helper.h"

int main()
{
    print(Channel::Red);

    return 0;
}
