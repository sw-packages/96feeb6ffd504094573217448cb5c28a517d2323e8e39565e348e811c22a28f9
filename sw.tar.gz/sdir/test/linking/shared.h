#ifndef SHARED_H
#define SHARED_H

#include <enum.h>

BETTER_ENUM(Channel, int, Red, Green, Blue)

#endif // #ifndef SHARED_H
