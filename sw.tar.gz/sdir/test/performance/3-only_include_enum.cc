#include <enum.h>

int main()
{
    return 0;
}
